
<?php

include "include/connection.php";



if(!empty($_POST['search'])){

  $search=$_POST['search'];
  $sql="SELECT * FROM employess  where CONCAT(emp_name , emp_fname , emp_username , emp_job) LIKE '%$search%'";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  


}else{

  $sql="SELECT * FROM employess";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  
  
  
}




?>

<!doctype html>
<html lang="en">

<head>
  
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">

  <title>Hello, world!</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
     	<img src="1.jpg" alt="" style="width:180px;" />
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="add_item.php">جنس جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="add_emp.php">کامند جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php">لیست اجناس</a>
            </li>
            
          </ul>
        </div>

        <div class="col-md-6" id="fsearch">
            <form class="form-inline" action="" method="post">
                <div class="form-group">
                  <input type="text" class="form-control" name="search" placeholder="جستجو">

                  <button type="submit" class="btn btn-primary"> جستجو</button>
                </div>
                
                
              </form>
        </div>

        <div class="col-md-2">
          <h2 class="title">لیست کارمندان</h2>
        </div>

      </div>
      <br>

      <div class="row" id="content">
        <div class="col-md-12">
                  <table class="table table-striped" dir="rtl">
                    <thead>
                        <tr class="btn-primary">
                          <th>نام کارمند</th>
                          <th>نام پدر</th>
                          <th>تخلص</th>
                          <th>وظیفه</th>
                          <th>عملیات</th>

                        </tr>
                    </thead>
                    <TBODy>

                    <?php





                  
                   if(mysqli_num_rows($result)>0){
                      while($row=mysqli_fetch_row($result)){

                        echo "<tr>";
                            echo"<td>".$row[1]." </td>";
                            echo"<td>".$row[2]." </td>";
                            echo"<td>".$row[3]." </td>";
                            echo"<td>".$row[4]." </td>";
                            echo"<td><a href='edit_emp.php?id=".$row[1]."'>اصلاح</a> </td>";

                        echo "<tr>";

                      }

                   }
                    
                    ?>


                     

                      
                    </TBODy>


                  </table>
        </div>
      </div>

  </div>





 		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
		<script type="text/javascript" src="bootstrap/dist/js/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/dist/js/bootstrap.min.js"></script>
</body>

</html>