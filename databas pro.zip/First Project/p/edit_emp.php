
<?php

include "include/connection.php";

$name='';
$fname="";
$surname="";
$job="";
$id =$_GET['id'];

if(isset($_POST['subbtn'])){
  //update data

  if(!empty($_POST['name'])){
    $name=$_POST['name'];
  }
  if(!empty($_POST['fname'])){
    $fname=$_POST['fname'];
  }
  if(!empty($_POST['surname'])){
    $surname=$_POST['surname'];
  }
  if(!empty($_POST['job'])){
    $job=$_POST['job'];
  }
  
  $upsql="update employess set emp_name='$name',emp_fname='$fname',emp_surname='$surname',emp_job='$job' where emp_id=$id";
  
  if(mysqli_query($connection,$upsql)){


    echo "موفقانه ویرایش شد ";
    header("location:list_emp.php");
  }else{
    echo "موفقانه ویرایش نشد ";
    header("location:edit_emp.php?id=$id");
  }

}else{

  
   $sql="SELECT * FROM emplyess where emp_id=$id";
   $result=mysqli_query($connection,$sql);
   $row=mysqli_fetch_row($result);
}



?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>Hello world!</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
			<img src="1.jpg" alt="" style="width:180px;" />
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="btn btn-primary" href="list_emp.php"> برگشت</a>
            </li>
          
          </ul>
        </div>

        

      </div>
      <br>

      <div class="row"  dir="rtl" id="content">
      <div class="col-md-12" >
          <h2 class="title" style="text-align: right;"> ویرایش کارمند</h2>

<br><br>

         
          <form  style="text-align: right;" action="" method="POST">
              <div class="form-group row" >
                <label for="inputEmail3"   class="col-sm-2 col-form-label">نام کامند</label>
                <div class="col-sm-10">
                  <input type="text" name="name" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                   class="form-control" id="inputEmail3" placeholder="نام کامند">
                </div>
              </div>

              <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"> نام پدر</label>
                  <div class="col-sm-10">
                    <input type="text" name="fname" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                     class="form-control" id="inputEmail3" placeholder="نام پدر">
                  </div>
                </div>

                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"> تخلص</label>
                    <div class="col-sm-10">
                      <input type="text" name="surname" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                       class="form-control" id="inputEmail3" placeholder="تخلص ">
                    </div>
                  </div>

                  <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">وظیفه </label>
                      <div class="col-sm-10">
                        <input type="text" name="job" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                         class="form-control" id="inputEmail3" placeholder="وظیفه ">
                      </div>
                    </div>
             

              <div class="form-group row">
                  <div class="col-sm-10"></div>
                <div class="col-sm-2">
                  <button type="submit" name="subbtn" class="btn btn-primary btn-block"> ویرایش  </button>
                </div>
                
              </div>
            </form>
      



        

      </div>
      </div>

  </div>








		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
		<script type="text/javascript" src="bootstrap/dist/js/jquery.min.js"></script>
		<script type="text/javascript" src="bootstrap/dist/js/bootstrap.min.js"></script>
</body>

</html>